// Inserts sample books so search / filter / sort / pagination can be demonstrated.
// Run with:  npm run seed
// WARNING: this clears the books and borrowrecords collections first (users are not touched).
require('dotenv').config();

const mongoose = require('mongoose');
const connectDB = require('../src/config/db');
const Book = require('../src/models/Book');
const BorrowRecord = require('../src/models/BorrowRecord');

const books = [
  { title: 'Clean Code', author: 'Robert C. Martin', isbn: '9780132350884', category: 'Programming', totalCopies: 5, availableCopies: 5, publishedYear: 2008 },
  { title: 'The Pragmatic Programmer', author: 'Andrew Hunt, David Thomas', isbn: '9780135957059', category: 'Programming', totalCopies: 4, availableCopies: 3, publishedYear: 2019 },
  { title: 'Eloquent JavaScript', author: 'Marijn Haverbeke', isbn: '9781593279509', category: 'Programming', totalCopies: 6, availableCopies: 6, publishedYear: 2018 },
  { title: 'Node.js Design Patterns', author: 'Mario Casciaro', isbn: '9781839214110', category: 'Programming', totalCopies: 3, availableCopies: 3, publishedYear: 2020 },
  { title: 'Introduction to Algorithms', author: 'Thomas H. Cormen', isbn: '9780262046305', category: 'Computer Science', totalCopies: 3, availableCopies: 3, publishedYear: 2022 },
  { title: 'Database System Concepts', author: 'Abraham Silberschatz', isbn: '9780078022159', category: 'Computer Science', totalCopies: 4, availableCopies: 2, publishedYear: 2019 },
  { title: 'The Alchemist', author: 'Paulo Coelho', isbn: '9780062315007', category: 'Fiction', totalCopies: 5, availableCopies: 0, publishedYear: 1988 },
  { title: 'To Kill a Mockingbird', author: 'Harper Lee', isbn: '9780061120084', category: 'Fiction', totalCopies: 4, availableCopies: 4, publishedYear: 1960 },
  { title: 'Atomic Habits', author: 'James Clear', isbn: '9780735211292', category: 'Self-Help', totalCopies: 8, availableCopies: 7, publishedYear: 2018 },
  { title: 'A Brief History of Time', author: 'Stephen Hawking', isbn: '9780553380163', category: 'Science', totalCopies: 3, availableCopies: 2, publishedYear: 1988 },
  { title: 'Sapiens: A Brief History of Humankind', author: 'Yuval Noah Harari', isbn: '9780062316110', category: 'History', totalCopies: 4, availableCopies: 4, publishedYear: 2015 },
  { title: 'Rich Dad Poor Dad', author: 'Robert T. Kiyosaki', isbn: '9781612680194', category: 'Finance', totalCopies: 5, availableCopies: 0, publishedYear: 1997 },
];

const seed = async () => {
  await connectDB(process.env.MONGO_URI);

  await BorrowRecord.deleteMany({});
  await Book.deleteMany({});
  await Book.insertMany(books);

  console.log(`Seeded ${books.length} books.`);
  await mongoose.connection.close();
};

seed().catch(async (error) => {
  console.error('Seeding failed:', error.message);
  await mongoose.connection.close();
  process.exit(1);
});
