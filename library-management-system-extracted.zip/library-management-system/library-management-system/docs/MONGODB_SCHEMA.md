# MongoDB Schema Explanation

**Database:** `library_db` · **ODM:** Mongoose 8 · **Collections:** `users`, `books`, `borrowrecords`

## 1. Overview

The system uses three collections:

- **users** — registered people who can log in and borrow books.
- **books** — the library catalogue, including how many copies exist and how many are on the shelf.
- **borrowrecords** — one document per loan. It links a user to a book and tracks the loan from *borrowed* to *returned*.

Collections are connected by **references** (ObjectIds), not by embedding documents inside each other.

## 2. Relationships

```mermaid
erDiagram
    USERS ||--o{ BORROWRECORDS : "borrows"
    BOOKS ||--o{ BORROWRECORDS : "is borrowed in"

    USERS {
        ObjectId _id
        String name
        String email
        String password
        Date createdAt
    }
    BOOKS {
        ObjectId _id
        String title
        String author
        String isbn
        String category
        Number totalCopies
        Number availableCopies
        Number publishedYear
    }
    BORROWRECORDS {
        ObjectId _id
        ObjectId userId
        ObjectId bookId
        Date borrowDate
        Date dueDate
        Date returnDate
        String status
    }
```

- One **user** can have many borrow records (one-to-many).
- One **book** can appear in many borrow records (one-to-many).
- `borrowrecords` is therefore the link (junction) collection between users and books.

## 3. Collection: `users`

| Field | Type | Required | Rules / notes |
|---|---|---|---|
| `_id` | ObjectId | auto | Primary key |
| `name` | String | Yes | Trimmed, 2–50 characters |
| `email` | String | Yes | **Unique**, lower-cased, must look like an e-mail |
| `password` | String | Yes | Minimum 6 characters before hashing. Stored as a **bcrypt hash** (10 salt rounds). Excluded from query results by default (`select: false`) and removed from every API response |
| `createdAt` | Date | auto | Defaults to the registration time |

## 4. Collection: `books`

| Field | Type | Required | Rules / notes |
|---|---|---|---|
| `_id` | ObjectId | auto | Primary key |
| `title` | String | Yes | Trimmed |
| `author` | String | Yes | Trimmed |
| `isbn` | String | Yes | **Unique** |
| `category` | String | Yes | Used for filtering (case-insensitive) |
| `totalCopies` | Number | Yes | Whole number, at least 1 |
| `availableCopies` | Number | No | Whole number, between 0 and `totalCopies`. Defaults to `totalCopies` when a book is created |
| `publishedYear` | Number | Yes | Whole number between 1000 and the current year. Used for sorting |

## 5. Collection: `borrowrecords`

| Field | Type | Required | Rules / notes |
|---|---|---|---|
| `_id` | ObjectId | auto | Primary key |
| `userId` | ObjectId → `users` | Yes | Who borrowed the book |
| `bookId` | ObjectId → `books` | Yes | Which book was borrowed |
| `borrowDate` | Date | auto | Defaults to the time of borrowing |
| `dueDate` | Date | Yes | `borrowDate` + `LOAN_PERIOD_DAYS` (default 14 days) |
| `returnDate` | Date | No | `null` until the book is returned |
| `status` | String | auto | `"borrowed"` (default) or `"returned"` |

## 6. Indexes and constraints

| Collection | Index | Purpose |
|---|---|---|
| `users` | `email` — unique | One account per e-mail; fast lookup at login |
| `books` | `isbn` — unique | The same ISBN cannot be added twice |
| `books` | `category`, `publishedYear` | Faster filtering and sorting |
| `borrowrecords` | `(userId, bookId)` — unique, **partial** (`status = "borrowed"`) | A user can hold only one active loan of the same book, even if two requests arrive at the same moment. After the book is returned the user may borrow it again |

## 7. Why references instead of embedding?

- A book is shared by many users, so copying book details into every user document would duplicate data.
- Borrow history grows continuously; embedding it would make `users` or `books` documents bigger with every loan.
- `availableCopies` is stored directly on the book, so checking availability is a single, fast read.
- When book details are needed (for example in *My Borrowed Books*), the API uses `populate` to join them.

## 8. How borrowing and returning change the data

**Borrow** (`POST /api/borrow/:bookId`)

1. Check that the user has no active record (`status = "borrowed"`) for this book.
2. In **one atomic update**, decrease `books.availableCopies` by 1 only if it is greater than 0.
3. Insert a document into `borrowrecords` with `borrowDate`, `dueDate`, `returnDate = null`, `status = "borrowed"`.
   If this insert fails, the copy is given back.

**Return** (`PATCH /api/borrow/:bookId/return`)

1. In **one atomic update**, change the active record to `status = "returned"` and set `returnDate`. Only one request can succeed, so a second call is rejected.
2. Increase `books.availableCopies` by 1.

## 9. Data-integrity rules

- ISBN and e-mail are unique.
- `availableCopies` is never below 0 and never above `totalCopies`.
- A book cannot be deleted while it is borrowed; when it is deleted, its old (returned) records are removed too, so no orphan references remain.
- Changing `totalCopies` keeps the number of borrowed copies unchanged.
- Passwords exist only as bcrypt hashes.

## 10. Sample documents

**users**

```json
{
  "_id": "665f1c2e8f1b2c0012a4b111",
  "name": "Akshat Kishore",
  "email": "akshat@example.com",
  "password": "$2a$10$...60-character-bcrypt-hash...",
  "createdAt": "2026-11-02T10:15:30.123Z"
}
```

**books**

```json
{
  "_id": "665f1d008f1b2c0012a4b222",
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "isbn": "9780132350884",
  "category": "Programming",
  "totalCopies": 5,
  "availableCopies": 4,
  "publishedYear": 2008
}
```

**borrowrecords**

```json
{
  "_id": "665f1d338f1b2c0012a4b333",
  "userId": "665f1c2e8f1b2c0012a4b111",
  "bookId": "665f1d008f1b2c0012a4b222",
  "borrowDate": "2026-11-02T10:20:00.000Z",
  "dueDate": "2026-11-16T10:20:00.000Z",
  "returnDate": null,
  "status": "borrowed"
}
```
