# API Screenshots

All screenshots were taken with **Postman** against the running API (`http://localhost:5000`) and with **MongoDB Compass** for the database. Request numbers (e.g. *1.1*) refer to the requests in the [Postman collection](../postman/Library-Management-System.postman_collection.json).

## User Management & Authentication

### Register a new user

`POST /api/users/register` — expected **201 Created**

![Register a new user](../screenshots/01_register_user.png)

### Login - JWT token returned

`POST /api/users/login` — expected **200 OK**

![Login - JWT token returned](../screenshots/02_login_user_token.png)

### Protected route without a token is blocked

`POST /api/borrow/:bookId` — expected **401 Unauthorized**

![Protected route without a token is blocked](../screenshots/03_unauthorized_401.png)

## Book Management

### Add a book

`POST /api/books` — expected **201 Created**

![Add a book](../screenshots/04_add_book.png)

### Duplicate ISBN is rejected

`POST /api/books` — expected **409 Conflict**

![Duplicate ISBN is rejected](../screenshots/05_duplicate_isbn_409.png)

### Required-field validation

`POST /api/books` — expected **400 Bad Request**

![Required-field validation](../screenshots/06_validation_error_400.png)

### Get a single book

`GET /api/books/:id` — expected **200 OK**

![Get a single book](../screenshots/08_get_book_by_id.png)

### Update a book

`PUT /api/books/:id` — expected **200 OK**

![Update a book](../screenshots/09_update_book.png)

### Delete a book

`DELETE /api/books/:id` — expected **200 OK**

![Delete a book](../screenshots/14_delete_book.png)

## Search, Filter, Sort & Pagination

### List books with pagination

`GET /api/books?page=1&limit=5` — expected **200 OK**

![List books with pagination](../screenshots/07_get_all_books_pagination.png)

### Search by title / author

`GET /api/books/search?search=martin` — expected **200 OK**

![Search by title / author](../screenshots/10_search_title_author.png)

### Filter by category

`GET /api/books?category=programming` — expected **200 OK**

![Filter by category](../screenshots/11_filter_by_category.png)

### Show available books only

`GET /api/books?available=true` — expected **200 OK**

![Show available books only](../screenshots/12_available_books_only.png)

### Sort by published year

`GET /api/books?sortBy=publishedYear&order=asc` — expected **200 OK**

![Sort by published year](../screenshots/13_sort_by_published_year.png)

## Borrow & Return

### Check availability of a book

`GET /api/books/:id/availability` — expected **200 OK**

![Check availability of a book](../screenshots/15_check_availability.png)

### Borrow a book (copies reduced, due date saved)

`POST /api/borrow/:bookId` — expected **201 Created**

![Borrow a book (copies reduced, due date saved)](../screenshots/16_borrow_book.png)

### Borrowing the same book again before returning is blocked

`POST /api/borrow/:bookId` — expected **409 Conflict**

![Borrowing the same book again before returning is blocked](../screenshots/17_borrow_duplicate_blocked_409.png)

### Borrowing a book with 0 copies is blocked

`POST /api/borrow/:bookId` — expected **409 Conflict**

![Borrowing a book with 0 copies is blocked](../screenshots/18_borrow_no_copies_blocked_409.png)

### View my borrowed books

`GET /api/borrow/my-books` — expected **200 OK**

![View my borrowed books](../screenshots/19_my_borrowed_books.png)

### Return a book (copies increased)

`PATCH /api/borrow/:bookId/return` — expected **200 OK**

![Return a book (copies increased)](../screenshots/20_return_book.png)

### Returning an already returned book is blocked

`PATCH /api/borrow/:bookId/return` — expected **409 Conflict**

![Returning an already returned book is blocked](../screenshots/21_return_again_blocked_409.png)

## Automated API tests

### Postman Collection Runner - all tests passed

![Postman Collection Runner - all tests passed](../screenshots/22_postman_runner_all_tests_passed.png)

## MongoDB collections

### MongoDB `users` collection - passwords stored as bcrypt hashes

![MongoDB `users` collection - passwords stored as bcrypt hashes](../screenshots/23_mongodb_users_hashed_password.png)

### MongoDB `books` and `borrowrecords` collections

![MongoDB `books` and `borrowrecords` collections](../screenshots/24_mongodb_books_and_borrowrecords.png)
