require('dotenv').config();

const app = require('./src/app');
const connectDB = require('./src/config/db');

// Stop early with a clear message if the .env file is missing or incomplete
const REQUIRED_ENV = ['MONGO_URI', 'JWT_SECRET'];
const missing = REQUIRED_ENV.filter((key) => !process.env[key]);
if (missing.length > 0) {
  console.error(`Missing required environment variable(s): ${missing.join(', ')}`);
  console.error('Create a .env file (copy .env.example) and try again.');
  process.exit(1);
}

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  await connectDB(process.env.MONGO_URI);

  app.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on http://localhost:${PORT}`);
  });
};

startServer();

process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection:', error.message);
  process.exit(1);
});
