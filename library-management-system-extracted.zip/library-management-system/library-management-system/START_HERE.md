# START HERE 👋  (sirf tumhare liye — ye file GitHub pe mat daalna)

Is zip me sab ready hai. Tumhe sirf 5 kaam karne hain (~25 min). Code ke andar kuch likhna nahi hai.

| Point 8 item | Kahan hai |
|---|---|
| Source code | `library-management-system/` folder |
| GitHub link | Step 4 me banega (tumhare account se) |
| README | `library-management-system/README.md` |
| Postman collection | `library-management-system/postman/Library-Management-System.postman_collection.json` |
| API screenshots | Step 3 me `library-management-system/screenshots/` me daalne hain (list neeche) |
| MongoDB schema explanation | `library-management-system/docs/MONGODB_SCHEMA.md` (+ chat me Doc link — Word/PDF download kar sakte ho) |

---

## Step 1 — Server chalao (5 min)
Pehle MongoDB chalu hona chahiye (local ya Atlas).

```bash
cd library-management-system
npm install
npm run seed     # 12 sample books daal deta hai
npm run dev      # server: http://localhost:5000
```

`.env` pehle se bani hui hai. Atlas use kar rahe ho toh `.env` me `MONGO_URI` badal do.
Terminal me `MongoDB connected` aur `Server running` dikhna chahiye.

## Step 2 — Postman me test (3 min)
1. Postman → **Import** → `postman/Library-Management-System.postman_collection.json`
2. Collection pe click → **Run** → **Run Library Management System API**
3. Sab tests **green** aane chahiye. Kuch **red** aaye toh response/error ka screenshot mujhe bhej do, fix kar dunga.

## Step 3 — Screenshots (10–12 min)
Har request ko Postman me kholo (numbers 1.1, 1.4, ... request ke naam me likhe hain), **Send** dabao, response + status code ka screenshot lo, aur `library-management-system/screenshots/` me neeche wale naam se save karo.
**Naam bilkul same rakhna** — `docs/API_SCREENSHOTS.md` me yehi naam use hue hain.

Pehle requests ko upar se neeche order me Send karo (1.1 → 1.4 → 2.1 → ...), kyunki token aur ids apne aap save hote hain.
⭐ = zaroori. Time kam ho toh sirf ⭐ wale lo.

| ⭐ | File name | Kahan se | Kya dikhna chahiye |
|---|---|---|---|
| ⭐ | 01_register_user.png | Postman → 1.1 | Register a new user |
| ⭐ | 02_login_user_token.png | Postman → 1.4 | Login - JWT token returned |
| ⭐ | 03_unauthorized_401.png | Postman → 3.1 | Protected route without a token is blocked |
| ⭐ | 04_add_book.png | Postman → 2.1 | Add a book |
| ⭐ | 05_duplicate_isbn_409.png | Postman → 2.2 | Duplicate ISBN is rejected |
| ⭐ | 06_validation_error_400.png | Postman → 2.3 | Required-field validation |
| ⭐ | 07_get_all_books_pagination.png | Postman → 2.5 | List books with pagination |
|  | 08_get_book_by_id.png | Postman → 2.6 | Get a single book |
| ⭐ | 09_update_book.png | Postman → 2.7 | Update a book |
| ⭐ | 10_search_title_author.png | Postman → 2.9 | Search by title / author |
| ⭐ | 11_filter_by_category.png | Postman → 2.10 | Filter by category |
| ⭐ | 12_available_books_only.png | Postman → 2.11 | Show available books only |
| ⭐ | 13_sort_by_published_year.png | Postman → 2.12 | Sort by published year |
| ⭐ | 14_delete_book.png | Postman → 2.18 (pehle 2.17 Send karo) | Delete a book |
|  | 15_check_availability.png | Postman → 3.2 | Check availability of a book |
| ⭐ | 16_borrow_book.png | Postman → 3.3 | Borrow a book (copies reduced, due date saved) |
| ⭐ | 17_borrow_duplicate_blocked_409.png | Postman → 3.4 | Borrowing the same book again before returning is blocked |
| ⭐ | 18_borrow_no_copies_blocked_409.png | Postman → 3.6 (pehle 3.5 Send karo) | Borrowing a book with 0 copies is blocked |
| ⭐ | 19_my_borrowed_books.png | Postman → 3.7 | View my borrowed books |
| ⭐ | 20_return_book.png | Postman → 3.10 | Return a book (copies increased) |
| ⭐ | 21_return_again_blocked_409.png | Postman → 3.11 | Returning an already returned book is blocked |
| ⭐ | 22_postman_runner_all_tests_passed.png | Collection Runner | Postman Collection Runner - all tests passed |
| ⭐ | 23_mongodb_users_hashed_password.png | MongoDB Compass | MongoDB `users` collection - passwords stored as bcrypt hashes |
|  | 24_mongodb_books_and_borrowrecords.png | MongoDB Compass | MongoDB `books` and `borrowrecords` collections |

Tips:
- Screenshot me **status code (201/409...) aur response body dono** dikhne chahiye.
- Runner wala screenshot **sabse last** me lo, aur Compass wale screenshots Runner se **pehle** (Runner ka Cleanup folder test-data hata deta hai; chaho toh Runner me "4. Cleanup" untick kar do).
- Compass: connect `mongodb://127.0.0.1:27017` → `library_db` → `users` (password hashed dikhega), `books`, `borrowrecords`.

## Step 4 — GitHub (3 min)
1. github.com → **New repository** → naam `library-management-system` → Public → README / .gitignore wale options **tick mat karo** → Create.
2. Terminal me `library-management-system` folder ke andar:

```bash
git init
git add .
git commit -m "Library Book Management System - REST API (Node.js, Express, MongoDB)"
git branch -M main
git remote add origin https://github.com/<TUMHARA-GITHUB-USERNAME>/library-management-system.git
git push -u origin main
```

`.env` aur `node_modules` automatically ignore hote hain (`.gitignore`). Repo ka link copy kar lo.

## Step 5 — Sir ko bhejo
- Chat me email draft hai: **GitHub link paste karo**, zip attach karo, send.
- Zip banane se pehle `node_modules` folder aur `.env` file delete kar do (zip chhota rahega, secret nahi jayega).
- Optional: schema explanation ka Doc Word/PDF me download karke attach kar do.

---

### Agar kuch na chale
- `MongoDB connection failed` → MongoDB service chalu nahi hai, ya `.env` ka `MONGO_URI` galat hai.
- `EADDRINUSE` → port 5000 busy hai; `.env` me `PORT=5001` karo aur Postman collection variable `baseUrl` me bhi 5001.
- Postman me `401` → pehle request **1.4 Login** Send karo (token wahin se save hota hai).
