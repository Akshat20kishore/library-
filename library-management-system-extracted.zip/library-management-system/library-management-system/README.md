# Library Book Management System — REST API

A backend REST API for managing library **books**, **users** and **borrowing records**, built with **Node.js, Express.js and MongoDB (Mongoose)**.
Users register and log in (bcrypt + JWT), browse and search the catalogue, and borrow / return books while the stock is updated automatically.

> **Submitted by:** Akshat Kishore — B.Tech Computer Science & Engineering

---

## Contents

1. [Features](#features)
2. [Tech stack](#tech-stack)
3. [Project structure](#project-structure)
4. [Getting started](#getting-started)
5. [API endpoints](#api-endpoints)
6. [Request & response examples](#request--response-examples)
7. [Business rules](#business-rules)
8. [HTTP status codes](#http-status-codes)
9. [Database schema](#database-schema)
10. [Postman collection](#postman-collection)
11. [API screenshots](#api-screenshots)
12. [Design decisions](#design-decisions)

---

## Features

| Requirement | How it is implemented |
|---|---|
| **Book management** | Add, view, update and delete books (title, author, ISBN, category, total copies, available copies, published year) |
| **Search & filter** | Search by title/author, filter by category, show available books only, sort by published year |
| **Borrow management** | Borrow, check availability, copies reduced on borrow and increased on return, borrow/due dates saved, duplicate borrowing blocked until the book is returned |
| **User management** | Register and login, passwords hashed with **bcrypt**, **JWT** authentication, protected borrow/return routes |
| **Validation** | Required fields validated, unique ISBN, unique e-mail, numeric and range checks |
| **Pagination** | `page` and `limit` on every list endpoint, with total / totalPages / hasNextPage |
| **Error handling** | One centralized error handler, consistent JSON errors, proper HTTP status codes |
| **Architecture** | Separate `routes`, `controllers`, `models`, `config/db.js`, `middleware` and `utils` |

## Tech stack

- **Node.js** (18+) and **Express.js 4**
- **MongoDB** with **Mongoose 8**
- **bcryptjs** (pure-JavaScript implementation of bcrypt, 10 salt rounds) and **jsonwebtoken**
- **dotenv**, **cors**, **morgan** (request logging)
- **Postman** for API testing

## Project structure

```
library-management-system/
├── server.js                    # entry point: loads .env, connects to MongoDB, starts the server
├── package.json
├── .env.example                 # template for environment variables
├── scripts/
│   └── seed.js                  # inserts 12 sample books
├── src/
│   ├── app.js                   # Express app: middleware, routes, error handlers
│   ├── config/
│   │   └── db.js                # MongoDB connection
│   ├── models/
│   │   ├── User.js              # users collection
│   │   ├── Book.js              # books collection
│   │   └── BorrowRecord.js      # borrowrecords collection
│   ├── controllers/
│   │   ├── userController.js    # register, login
│   │   ├── bookController.js    # CRUD, search, filter, sort, availability
│   │   └── borrowController.js  # borrow, return, my borrowed books
│   ├── routes/
│   │   ├── userRoutes.js
│   │   ├── bookRoutes.js
│   │   └── borrowRoutes.js
│   ├── middleware/
│   │   ├── auth.js              # JWT "protect" middleware
│   │   └── errorHandler.js      # 404 handler + centralized error handler
│   └── utils/
│       ├── AppError.js          # custom error class
│       ├── asyncHandler.js      # forwards async errors to the error handler
│       └── pagination.js        # page / limit helpers
├── postman/
│   └── Library-Management-System.postman_collection.json
├── docs/
│   ├── MONGODB_SCHEMA.md        # MongoDB schema explanation
│   └── API_SCREENSHOTS.md       # screenshots of every API
└── screenshots/                 # image files used by API_SCREENSHOTS.md
```

## Getting started

**Prerequisites:** Node.js 18 or newer, MongoDB (local installation or a free MongoDB Atlas cluster) and Postman.

```bash
# 1. get the code
git clone <repository-url>
cd library-management-system

# 2. install dependencies
npm install

# 3. create the environment file
cp .env.example .env          # Windows: copy .env.example .env

# 4. (optional) insert 12 sample books
npm run seed

# 5. start the server
npm run dev                   # auto-restart with nodemon
# or
npm start
```

The API is now available at **http://localhost:5000** (health check: `GET /`).

### Environment variables

| Variable | Example | Description |
|---|---|---|
| `PORT` | `5000` | Port the server listens on |
| `NODE_ENV` | `development` | `development` or `production` |
| `MONGO_URI` | `mongodb://127.0.0.1:27017/library_db` | MongoDB connection string (local or Atlas) |
| `JWT_SECRET` | `a_long_random_string` | Secret used to sign JWTs |
| `JWT_EXPIRES_IN` | `1d` | Token lifetime |
| `LOAN_PERIOD_DAYS` | `14` | Days between borrow date and due date |

### Useful scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Start with auto-reload (nodemon) |
| `npm start` | Start normally |
| `npm run seed` | Reset books and borrow records and insert 12 sample books |
| `npm run test:api` | Run the whole Postman collection from the terminal with Newman (server must be running) |

## API endpoints

Base URL: `http://localhost:5000/api`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/users/register` | Public | Register a new user |
| POST | `/users/login` | Public | Login and receive a JWT |
| POST | `/books` | JWT | Add a book |
| GET | `/books` | Public | List books (search, filter, sort, pagination) |
| GET | `/books/search` | Public | Same as `GET /books` (search endpoint) |
| GET | `/books/:id` | Public | Get one book |
| GET | `/books/:id/availability` | Public | Check how many copies are available |
| PUT / PATCH | `/books/:id` | JWT | Update a book (send only the fields to change) |
| DELETE | `/books/:id` | JWT | Delete a book (blocked while it is borrowed) |
| POST | `/borrow/:bookId` | JWT | Borrow a book |
| PATCH | `/borrow/:bookId/return` | JWT | Return a book (`PUT` also works) |
| GET | `/borrow/my-books` | JWT | View my borrowed books |

Protected routes expect the header `Authorization: Bearer <token>`.

### Query parameters for `GET /api/books`

| Parameter | Example | Description |
|---|---|---|
| `search` (or `q`) | `?search=clean` | Case-insensitive partial match on **title or author** |
| `category` | `?category=programming` | Case-insensitive category filter |
| `available` | `?available=true` | `true` = only books with copies left, `false` = out of stock |
| `sortBy` | `?sortBy=publishedYear` | `publishedYear`, `title` or `author` |
| `order` | `?order=desc` | `asc` (default) or `desc` |
| `page`, `limit` | `?page=2&limit=5` | Pagination (defaults: page 1, limit 10, max 100) |

Example with everything combined:
`GET /api/books?search=a&category=programming&available=true&sortBy=publishedYear&order=desc&page=1&limit=5`

`GET /api/borrow/my-books` accepts `status=borrowed|returned`, `page` and `limit`.

## Request & response examples

**Register** — `POST /api/users/register`

```json
{ "name": "Akshat Kishore", "email": "akshat@example.com", "password": "Secret@123" }
```
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": { "_id": "665f1c2e8f1b2c0012a4b111", "name": "Akshat Kishore", "email": "akshat@example.com", "createdAt": "2026-11-02T10:15:30.123Z" }
}
```

**Login** — `POST /api/users/login`

```json
{ "email": "akshat@example.com", "password": "Secret@123" }
```
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": { "_id": "665f1c2e8f1b2c0012a4b111", "name": "Akshat Kishore", "email": "akshat@example.com", "createdAt": "2026-11-02T10:15:30.123Z" }
  }
}
```

**Add a book** — `POST /api/books` (with `Authorization: Bearer <token>`)

```json
{ "title": "Clean Code", "author": "Robert C. Martin", "isbn": "9780132350884", "category": "Programming", "totalCopies": 5, "publishedYear": 2008 }
```
```json
{
  "success": true,
  "message": "Book added successfully",
  "data": {
    "_id": "665f1d008f1b2c0012a4b222", "title": "Clean Code", "author": "Robert C. Martin", "isbn": "9780132350884",
    "category": "Programming", "totalCopies": 5, "availableCopies": 5, "publishedYear": 2008
  }
}
```

**List books** — `GET /api/books?category=programming&page=1&limit=2`

```json
{
  "success": true,
  "count": 2,
  "pagination": { "total": 4, "page": 1, "limit": 2, "totalPages": 2, "hasNextPage": true, "hasPrevPage": false },
  "data": [ { "_id": "...", "title": "Clean Code", "...": "..." }, { "_id": "...", "title": "Eloquent JavaScript", "...": "..." } ]
}
```

**Borrow a book** — `POST /api/borrow/665f1d008f1b2c0012a4b222`

```json
{
  "success": true,
  "message": "Book borrowed successfully. Please return it by Mon Nov 16 2026.",
  "data": {
    "borrowRecord": {
      "_id": "665f1d338f1b2c0012a4b333", "userId": "665f1c2e8f1b2c0012a4b111", "bookId": "665f1d008f1b2c0012a4b222",
      "borrowDate": "2026-11-02T10:20:00.000Z", "dueDate": "2026-11-16T10:20:00.000Z", "returnDate": null, "status": "borrowed"
    },
    "book": { "_id": "665f1d008f1b2c0012a4b222", "title": "Clean Code", "availableCopies": 4 }
  }
}
```

**Return a book** — `PATCH /api/borrow/665f1d008f1b2c0012a4b222/return` → `status` becomes `"returned"`, `returnDate` is saved and `availableCopies` goes back up.

**Error format** (all errors look the same)

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    { "field": "author", "message": "Author is required" },
    { "field": "isbn", "message": "ISBN is required" }
  ]
}
```

## Business rules

- ISBN is **unique**; e-mail is **unique**.
- All required fields are validated; `availableCopies` can never be negative or greater than `totalCopies`.
- A book **cannot be borrowed when `availableCopies` is 0**.
- A user **cannot borrow the same book twice** before returning it.
- A book that is **already returned cannot be returned again**.
- Borrowing sets `borrowDate` and `dueDate` (borrow date + `LOAN_PERIOD_DAYS`) and reduces `availableCopies` by 1; returning sets `returnDate`, `status = returned` and increases `availableCopies` by 1.
- When `totalCopies` is changed, the number of copies currently borrowed is preserved (e.g. total 5 / available 3 → total 8 gives available 6).
- A book that is currently borrowed **cannot be deleted**.
- Passwords are never stored or returned in plain text.

## HTTP status codes

| Code | Used for |
|---|---|
| `200 OK` | Successful read, update, delete, login, return |
| `201 Created` | User registered, book added, book borrowed |
| `400 Bad Request` | Validation errors, invalid id, invalid query value, malformed JSON |
| `401 Unauthorized` | Missing / invalid / expired token, wrong credentials |
| `404 Not Found` | Book or borrow record not found, unknown route |
| `409 Conflict` | Duplicate ISBN or e-mail, already borrowed, no copies available, already returned, deleting a borrowed book |
| `500 Internal Server Error` | Unexpected server error |

## Database schema

Three collections, linked by ObjectId references. Full explanation, relationship diagram, indexes and sample documents: **[docs/MONGODB_SCHEMA.md](docs/MONGODB_SCHEMA.md)**

| Collection | Fields |
|---|---|
| `users` | `name`, `email` (unique), `password` (bcrypt hash), `createdAt` |
| `books` | `title`, `author`, `isbn` (unique), `category`, `totalCopies`, `availableCopies`, `publishedYear` |
| `borrowrecords` | `userId` → users, `bookId` → books, `borrowDate`, `dueDate`, `returnDate`, `status` (`borrowed` / `returned`) |

## Postman collection

File: [`postman/Library-Management-System.postman_collection.json`](postman/Library-Management-System.postman_collection.json)

1. Start the server (`npm run dev`).
2. In Postman: **Import** → select the file above.
3. Run the requests in order, or click **Run collection**. Request **1.4 Login** stores the JWT automatically; ids such as `bookId` are stored by the test scripts, so nothing has to be copied by hand.
4. The collection contains 39 requests with automatic test assertions covering every success case and every error case (400, 401, 404, 409).

Terminal alternative: `npm run test:api` (runs the same collection with Newman).

## API screenshots

Screenshots of every endpoint (success and error cases) and of the MongoDB collections: **[docs/API_SCREENSHOTS.md](docs/API_SCREENSHOTS.md)**

## Design decisions

- **Atomic stock updates.** Borrowing uses a single `findOneAndUpdate` with the condition `availableCopies > 0`, so two users borrowing the last copy at the same time can never push the stock below zero. Returning marks the record as returned in one atomic step, so a repeated request cannot add the copy twice.
- **Duplicate-borrow protection in the database.** A partial unique index on `(userId, bookId)` for records with `status = "borrowed"` enforces the rule even under parallel requests, while still allowing the same user to borrow the book again after returning it.
- **References instead of embedding.** Borrow history grows without limit and books are shared by many users, so `borrowrecords` stores ids and the API uses `populate` to show book details.
- **Centralized error handling.** Controllers simply throw (`AppError`); one middleware converts Mongoose validation errors, bad ids, duplicate keys and JWT errors into clean JSON with the right status code.
- **Write routes are protected.** Only logged-in users can add, update or delete books; browsing and searching stay public.
- **bcryptjs.** Same bcrypt algorithm as the native `bcrypt` package, but without native compilation, so it installs everywhere.

**Possible improvements:** role-based access (admin / member), late-return fines, refresh tokens, rate limiting, automated tests.
