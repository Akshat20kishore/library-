const mongoose = require('mongoose');

// Collection: borrowrecords  ->  userId, bookId, borrowDate, dueDate, returnDate, status
const borrowRecordSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User id is required'],
    },
    bookId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Book',
      required: [true, 'Book id is required'],
    },
    borrowDate: {
      type: Date,
      default: Date.now,
    },
    dueDate: {
      type: Date,
      required: [true, 'Due date is required'],
    },
    returnDate: {
      type: Date,
      default: null, // stays null until the book is returned
    },
    status: {
      type: String,
      enum: {
        values: ['borrowed', 'returned'],
        message: 'Status must be either borrowed or returned',
      },
      default: 'borrowed',
    },
  },
  { versionKey: false }
);

// A user can hold only ONE active (not yet returned) loan of the same book.
// The index only applies to documents whose status is "borrowed", so the same user
// can borrow the same book again later, after returning it.
// This also protects against double-clicks / parallel requests.
borrowRecordSchema.index(
  { userId: 1, bookId: 1 },
  { unique: true, partialFilterExpression: { status: 'borrowed' } }
);

module.exports = mongoose.model('BorrowRecord', borrowRecordSchema);
