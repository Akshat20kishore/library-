const mongoose = require('mongoose');

// Small helper: a fresh "must be a whole number" validator for each field
const wholeNumber = () => ({
  validator: Number.isInteger,
  message: '{PATH} must be a whole number',
});

// Collection: books  ->  title, author, isbn, category, totalCopies, availableCopies, publishedYear
const bookSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
    },
    author: {
      type: String,
      required: [true, 'Author is required'],
      trim: true,
    },
    isbn: {
      type: String,
      required: [true, 'ISBN is required'],
      unique: true, // ISBN must be unique
      trim: true,
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      trim: true,
    },
    totalCopies: {
      type: Number,
      required: [true, 'Total copies is required'],
      min: [1, 'Total copies must be at least 1'],
      validate: wholeNumber(),
    },
    availableCopies: {
      type: Number,
      min: [0, 'Available copies cannot be negative'],
      validate: [
        wholeNumber(),
        {
          validator: function (value) {
            return value <= this.totalCopies;
          },
          message: 'Available copies cannot be greater than total copies',
        },
      ],
    },
    publishedYear: {
      type: Number,
      required: [true, 'Published year is required'],
      validate: [
        wholeNumber(),
        {
          validator: (value) => value >= 1000 && value <= new Date().getFullYear(),
          message: 'Published year must be between 1000 and the current year',
        },
      ],
    },
  },
  { versionKey: false }
);

// If availableCopies is not sent when a book is created, all copies are available
bookSchema.pre('validate', async function () {
  if (this.isNew && (this.availableCopies === undefined || this.availableCopies === null)) {
    this.availableCopies = this.totalCopies;
  }
});

// Indexes that speed up filtering and sorting
bookSchema.index({ category: 1 });
bookSchema.index({ publishedYear: 1 });

module.exports = mongoose.model('Book', bookSchema);
