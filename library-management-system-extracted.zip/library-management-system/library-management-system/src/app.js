const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const userRoutes = require('./routes/userRoutes');
const bookRoutes = require('./routes/bookRoutes');
const borrowRoutes = require('./routes/borrowRoutes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

// ---------- Global middleware ----------
app.use(cors());
app.use(express.json());
app.use(morgan('dev')); // prints every request in the terminal

// ---------- Health check ----------
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Library Book Management System API is running',
    endpoints: {
      users: '/api/users',
      books: '/api/books',
      borrow: '/api/borrow',
    },
  });
});

// ---------- API routes ----------
app.use('/api/users', userRoutes);
app.use('/api/books', bookRoutes);
app.use('/api/borrow', borrowRoutes);

// ---------- Error handling (must be last) ----------
app.use(notFound);
app.use(errorHandler);

module.exports = app;
