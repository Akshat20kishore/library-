const Book = require('../models/Book');
const BorrowRecord = require('../models/BorrowRecord');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { getPagination, buildPaginationMeta } = require('../utils/pagination');

const DAY_IN_MS = 24 * 60 * 60 * 1000;

// @desc    Borrow a book
// @route   POST /api/borrow/:bookId
// @access  Private (JWT)
const borrowBook = asyncHandler(async (req, res) => {
  const { bookId } = req.params;
  const userId = req.user._id;

  // 1. The same user cannot borrow the same book again before returning it
  const alreadyBorrowed = await BorrowRecord.findOne({ userId, bookId, status: 'borrowed' });
  if (alreadyBorrowed) {
    throw new AppError('You have already borrowed this book. Please return it before borrowing again.', 409);
  }

  // 2. Check availability AND reduce availableCopies in ONE atomic step.
  //    The filter { availableCopies: { $gt: 0 } } guarantees copies never go below 0,
  //    even if two users borrow the last copy at the same moment.
  const book = await Book.findOneAndUpdate(
    { _id: bookId, availableCopies: { $gt: 0 } },
    { $inc: { availableCopies: -1 } },
    { new: true }
  );

  if (!book) {
    const bookExists = await Book.exists({ _id: bookId });
    if (!bookExists) {
      throw new AppError('Book not found', 404);
    }
    throw new AppError('No copies available. This book is currently out of stock.', 409);
  }

  // 3. Save the borrow record with borrow date and due date
  const loanDays = parseInt(process.env.LOAN_PERIOD_DAYS, 10) || 14;
  const borrowDate = new Date();
  const dueDate = new Date(borrowDate.getTime() + loanDays * DAY_IN_MS);

  let borrowRecord;
  try {
    borrowRecord = await BorrowRecord.create({ userId, bookId, borrowDate, dueDate });
  } catch (error) {
    // Could not save the record -> give the copy back, then report the error
    await Book.updateOne({ _id: bookId }, { $inc: { availableCopies: 1 } });
    throw error;
  }

  res.status(201).json({
    success: true,
    message: `Book borrowed successfully. Please return it by ${dueDate.toDateString()}.`,
    data: {
      borrowRecord,
      book: {
        _id: book._id,
        title: book.title,
        availableCopies: book.availableCopies,
      },
    },
  });
});

// @desc    Return a borrowed book
// @route   PATCH /api/borrow/:bookId/return   (PUT works too)
// @access  Private (JWT)
const returnBook = asyncHandler(async (req, res) => {
  const { bookId } = req.params;
  const userId = req.user._id;

  // Mark the active record as returned. Doing it in one atomic step means that
  // if the request is sent twice, only the first one succeeds (copies are never added twice).
  const borrowRecord = await BorrowRecord.findOneAndUpdate(
    { userId, bookId, status: 'borrowed' },
    { status: 'returned', returnDate: new Date() },
    { new: true }
  );

  if (!borrowRecord) {
    const returnedBefore = await BorrowRecord.exists({ userId, bookId, status: 'returned' });
    if (returnedBefore) {
      throw new AppError('This book has already been returned.', 409);
    }
    throw new AppError('No active borrow record found. You have not borrowed this book.', 404);
  }

  // Put the copy back on the shelf
  const book = await Book.findByIdAndUpdate(bookId, { $inc: { availableCopies: 1 } }, { new: true });

  res.status(200).json({
    success: true,
    message: 'Book returned successfully',
    data: {
      borrowRecord,
      book: book ? { _id: book._id, title: book.title, availableCopies: book.availableCopies } : null,
    },
  });
});

// @desc    View my borrowed books (history). Use ?status=borrowed for books I still have.
// @route   GET /api/borrow/my-books
// @access  Private (JWT)
const getMyBorrowedBooks = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const { page, limit, skip } = getPagination(req.query);

  const filter = { userId: req.user._id };
  if (status !== undefined && status !== '') {
    if (!['borrowed', 'returned'].includes(status)) {
      throw new AppError('status must be either borrowed or returned', 400);
    }
    filter.status = status;
  }

  const [records, total] = await Promise.all([
    BorrowRecord.find(filter)
      .populate('bookId', 'title author isbn category') // replace the id with basic book details
      .sort({ borrowDate: -1, _id: -1 })
      .skip(skip)
      .limit(limit),
    BorrowRecord.countDocuments(filter),
  ]);

  const now = new Date();
  const data = records.map((record) => ({
    ...record.toObject(),
    isOverdue: record.status === 'borrowed' && record.dueDate < now,
  }));

  res.status(200).json({
    success: true,
    count: data.length,
    pagination: buildPaginationMeta(total, page, limit),
    data,
  });
});

module.exports = { borrowBook, returnBook, getMyBorrowedBooks };
