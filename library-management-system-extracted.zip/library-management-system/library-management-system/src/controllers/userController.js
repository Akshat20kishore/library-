const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Register a new user
// @route   POST /api/users/register
// @access  Public
const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body || {};

  // Field validation and bcrypt hashing both happen inside the User model
  const user = await User.create({ name, email, password });

  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    data: user, // password hash is removed by the model's toJSON
  });
});

// @desc    Login and receive a JWT
// @route   POST /api/users/login
// @access  Public
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    throw new AppError('Email and password are required', 400);
  }

  // Reject objects such as { "$gt": "" } (NoSQL injection attempt)
  if (typeof email !== 'string' || typeof password !== 'string') {
    throw new AppError('Email and password must be text values', 400);
  }

  const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');
  const passwordMatches = user && (await user.comparePassword(password));

  // Same message for "no such user" and "wrong password" so attackers learn nothing
  if (!passwordMatches) {
    throw new AppError('Invalid email or password', 401);
  }

  res.status(200).json({
    success: true,
    message: 'Login successful',
    data: {
      token: user.generateToken(),
      user,
    },
  });
});

module.exports = { register, login };
