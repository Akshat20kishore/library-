const Book = require('../models/Book');
const BorrowRecord = require('../models/BorrowRecord');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { getPagination, buildPaginationMeta } = require('../utils/pagination');

const SORTABLE_FIELDS = ['publishedYear', 'title', 'author'];
const UPDATABLE_FIELDS = ['title', 'author', 'isbn', 'category', 'totalCopies', 'availableCopies', 'publishedYear'];

// Escape special regex characters so user input is always treated as plain text
const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// @desc    Add a new book
// @route   POST /api/books
// @access  Private (JWT)
const createBook = asyncHandler(async (req, res) => {
  const { title, author, isbn, category, totalCopies, availableCopies, publishedYear } = req.body || {};

  // Required-field validation + unique ISBN are handled by the Book model
  const book = await Book.create({ title, author, isbn, category, totalCopies, availableCopies, publishedYear });

  res.status(201).json({
    success: true,
    message: 'Book added successfully',
    data: book,
  });
});

// @desc    List books  (search + filter + sort + pagination)
// @route   GET /api/books   and   GET /api/books/search
// @access  Public
//   ?search=clean            title OR author contains "clean" (case-insensitive)
//   ?category=programming    category filter
//   ?available=true          only books that have copies left
//   ?sortBy=publishedYear&order=desc
//   ?page=1&limit=10
const getBooks = asyncHandler(async (req, res) => {
  const { category, available, order } = req.query;
  const search = req.query.search || req.query.q;
  const sortBy = req.query.sortBy || req.query.sort;
  const { page, limit, skip } = getPagination(req.query);

  const filter = {};

  // Search by title or author
  if (search && String(search).trim()) {
    const regex = new RegExp(escapeRegex(String(search).trim()), 'i');
    filter.$or = [{ title: regex }, { author: regex }];
  }

  // Filter by category (case-insensitive, exact)
  if (category && String(category).trim()) {
    filter.category = new RegExp(`^${escapeRegex(String(category).trim())}$`, 'i');
  }

  // Show available books only (or only the ones that are out of stock)
  if (available !== undefined && available !== '') {
    const value = String(available).toLowerCase();
    if (!['true', 'false'].includes(value)) {
      throw new AppError('available must be either true or false', 400);
    }
    filter.availableCopies = value === 'true' ? { $gt: 0 } : 0;
  }

  // Sorting (default: order in which books were added)
  let sort = { _id: 1 };
  if (sortBy) {
    if (!SORTABLE_FIELDS.includes(sortBy)) {
      throw new AppError(`sortBy must be one of: ${SORTABLE_FIELDS.join(', ')}`, 400);
    }
    const direction = String(order || 'asc').toLowerCase();
    if (!['asc', 'desc'].includes(direction)) {
      throw new AppError('order must be either asc or desc', 400);
    }
    sort = { [sortBy]: direction === 'desc' ? -1 : 1, _id: 1 }; // _id keeps page order stable
  }

  const [books, total] = await Promise.all([
    Book.find(filter)
      .sort(sort)
      .collation({ locale: 'en', strength: 2 }) // case-insensitive sorting for title/author
      .skip(skip)
      .limit(limit),
    Book.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    count: books.length,
    pagination: buildPaginationMeta(total, page, limit),
    data: books,
  });
});

// @desc    Get one book
// @route   GET /api/books/:id
// @access  Public
const getBookById = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id); // invalid id -> CastError -> 400
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  res.status(200).json({ success: true, data: book });
});

// @desc    Check how many copies of a book are available
// @route   GET /api/books/:id/availability
// @access  Public
const getBookAvailability = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id).select('title totalCopies availableCopies');
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  res.status(200).json({
    success: true,
    data: {
      bookId: book._id,
      title: book.title,
      totalCopies: book.totalCopies,
      availableCopies: book.availableCopies,
      isAvailable: book.availableCopies > 0,
    },
  });
});

// @desc    Update a book (send only the fields you want to change)
// @route   PUT /api/books/:id   (PATCH works too)
// @access  Private (JWT)
const updateBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  // Take only the allowed fields from the request body
  const updates = {};
  UPDATABLE_FIELDS.forEach((field) => {
    if (req.body && req.body[field] !== undefined) updates[field] = req.body[field];
  });

  if (Object.keys(updates).length === 0) {
    throw new AppError(`Send at least one field to update: ${UPDATABLE_FIELDS.join(', ')}`, 400);
  }

  // If only totalCopies changes, keep the number of borrowed copies the same:
  // e.g. total 5 / available 3 (2 borrowed) -> new total 8 gives available 6.
  if (updates.totalCopies !== undefined && updates.availableCopies === undefined) {
    const newTotal = Number(updates.totalCopies);
    const copiesBorrowed = book.totalCopies - book.availableCopies;

    if (Number.isInteger(newTotal)) {
      if (newTotal < copiesBorrowed) {
        throw new AppError(
          `Total copies cannot be less than the ${copiesBorrowed} copies that are currently borrowed`,
          409
        );
      }
      updates.availableCopies = newTotal - copiesBorrowed;
    }
  }

  book.set(updates);

  if (book.availableCopies > book.totalCopies) {
    throw new AppError('Available copies cannot be greater than total copies', 400);
  }

  await book.save(); // runs schema validation; duplicate ISBN -> 409 via error handler

  res.status(200).json({
    success: true,
    message: 'Book updated successfully',
    data: book,
  });
});

// @desc    Delete a book
// @route   DELETE /api/books/:id
// @access  Private (JWT)
const deleteBook = asyncHandler(async (req, res) => {
  const book = await Book.findById(req.params.id);
  if (!book) {
    throw new AppError('Book not found', 404);
  }

  // Do not delete a book while somebody still has it
  const activeLoans = await BorrowRecord.countDocuments({ bookId: book._id, status: 'borrowed' });
  if (activeLoans > 0) {
    throw new AppError(`Cannot delete this book because it is currently borrowed by ${activeLoans} user(s)`, 409);
  }

  await BorrowRecord.deleteMany({ bookId: book._id }); // remove its old (returned) records too
  await book.deleteOne();

  res.status(200).json({
    success: true,
    message: 'Book deleted successfully',
  });
});

module.exports = {
  createBook,
  getBooks,
  getBookById,
  getBookAvailability,
  updateBook,
  deleteBook,
};
