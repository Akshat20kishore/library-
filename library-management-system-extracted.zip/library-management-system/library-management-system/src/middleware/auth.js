const jwt = require('jsonwebtoken');
const User = require('../models/User');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

// Protects a route: the request must carry a valid JWT
//   Authorization: Bearer <token>
const protect = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    throw new AppError('Not authorized. Please log in and send the token as "Authorization: Bearer <token>"', 401);
  }

  const token = header.split(' ')[1];

  // Throws JsonWebTokenError / TokenExpiredError if the token is wrong -> handled centrally (401)
  const decoded = jwt.verify(token, process.env.JWT_SECRET);

  const user = await User.findById(decoded.id);
  if (!user) {
    throw new AppError('The user belonging to this token no longer exists', 401);
  }

  req.user = user; // available in controllers as req.user
  next();
});

module.exports = { protect };
