const AppError = require('../utils/AppError');

// Runs when no route matched -> 404
const notFound = (req, res, next) => {
  next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));
};

const DUPLICATE_MESSAGES = {
  email: 'This email is already registered',
  isbn: 'A book with this ISBN already exists',
};

// Centralized error handler: every error in the app ends up here and is sent
// to the client in one consistent format:
// { success: false, message: "...", errors?: [ { field, message } ] }
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message = err.message || 'Something went wrong';
  let errors = err.isOperational ? err.errors : undefined;

  if (err.name === 'ValidationError') {
    // Mongoose schema validation failed (required field missing, min/max, wrong type ...)
    statusCode = 400;
    message = 'Validation failed';
    errors = Object.values(err.errors).map((e) => ({
      field: e.path,
      message: e.name === 'CastError' ? `${e.path} must be a valid ${e.kind}` : e.message,
    }));
  } else if (err.name === 'CastError') {
    // Invalid ObjectId or other badly formatted value in the URL / query
    statusCode = 400;
    message = `Invalid ${err.path === '_id' ? 'id' : err.path}: ${String(err.value)}`;
  } else if (err.code === 11000) {
    // MongoDB duplicate key (unique index violated)
    statusCode = 409;
    const fields = Object.keys(err.keyValue || err.keyPattern || {});
    if (fields.includes('userId') && fields.includes('bookId')) {
      message = 'You have already borrowed this book. Please return it before borrowing again.';
    } else {
      message = DUPLICATE_MESSAGES[fields[0]] || `Duplicate value for: ${fields.join(', ')}`;
    }
  } else if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    message = 'Invalid token. Please log in again.';
  } else if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    message = 'Your token has expired. Please log in again.';
  } else if (err.type === 'entity.parse.failed') {
    // Malformed JSON in the request body
    statusCode = 400;
    message = 'Invalid JSON in request body';
  }

  if (statusCode >= 500) {
    console.error(err);
    if (process.env.NODE_ENV === 'production') message = 'Internal server error';
  }

  const response = { success: false, message };
  if (Array.isArray(errors) && errors.length > 0) response.errors = errors;
  if (process.env.NODE_ENV === 'development' && statusCode >= 500) response.stack = err.stack;

  res.status(statusCode).json(response);
};

module.exports = { notFound, errorHandler };
