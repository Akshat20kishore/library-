const express = require('express');
const { protect } = require('../middleware/auth');
const { borrowBook, returnBook, getMyBorrowedBooks } = require('../controllers/borrowController');

const router = express.Router();

router.use(protect); // every borrow/return route needs a valid JWT

router.get('/my-books', getMyBorrowedBooks);
router.post('/:bookId', borrowBook);
router.patch('/:bookId/return', returnBook);
router.put('/:bookId/return', returnBook);

module.exports = router;
