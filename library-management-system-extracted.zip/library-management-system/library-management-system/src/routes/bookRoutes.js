const express = require('express');
const { protect } = require('../middleware/auth');
const {
  createBook,
  getBooks,
  getBookById,
  getBookAvailability,
  updateBook,
  deleteBook,
} = require('../controllers/bookController');

const router = express.Router();

// Public: anyone can browse and search the catalogue
router.get('/', getBooks);
router.get('/search', getBooks); // same as GET /api/books?search=...  (must stay above /:id)
router.get('/:id/availability', getBookAvailability);
router.get('/:id', getBookById);

// Protected: only logged-in users can change the catalogue
router.post('/', protect, createBook);
router.put('/:id', protect, updateBook);
router.patch('/:id', protect, updateBook);
router.delete('/:id', protect, deleteBook);

module.exports = router;
